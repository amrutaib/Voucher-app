export const jsonPlaceholderData = "https://jsonplaceholder.typicode.com/users";
